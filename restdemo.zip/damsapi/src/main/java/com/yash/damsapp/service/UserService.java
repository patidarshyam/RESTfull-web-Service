package com.yash.damsapp.service;

import java.util.ArrayList;
import java.util.List;

import com.yash.damsapp.model.User;

public class UserService {
	
	public List<User> getAllUsers(){
		List<User> users = new ArrayList<User>();
		
		User u1=new User(1, "shyam", "5345355");
		User u2=new User(2, "shyam patidar", "5345000355");
		
		users.add(u1);
		users.add(u2);
		return users;
	}
}
