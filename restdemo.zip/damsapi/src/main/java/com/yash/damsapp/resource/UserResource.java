package com.yash.damsapp.resource;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.yash.damsapp.model.User;
import com.yash.damsapp.service.UserService;

@Path("/users")
public class UserResource {
	private UserService userService=new UserService();
	
	/*@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String getMessage(){
		return "hello";
	}*/

	/*@GET
	@Produces(MediaType.APPLICATION_XML)
	public List<User> getAllUsers(){
		return userService.getAllUsers();	
	}*/
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<User> getAllUsers(){
		return userService.getAllUsers();	
	}
	
	@GET
	@Path("/{id}")
	@Produces(MediaType.TEXT_PLAIN)
	public String test(@PathParam("id") int id){
		return " id = "+id;	
	}
}
